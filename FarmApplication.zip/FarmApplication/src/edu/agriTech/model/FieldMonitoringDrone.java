package edu.agriTech.model;

import javafx.scene.image.ImageView;

public class FieldMonitoringDrone extends AgriculturalUnit {
    private ImageView droneVisual;

    // Constructor
    public FieldMonitoringDrone(String unitIdentifier, double unitValue, float locationXAxis, float locationYAxis, 
                                float sizeDepth, float sizeWidth, float sizeHeight, ImageView droneVisual) {
        super(unitIdentifier, unitValue, locationXAxis, locationYAxis, sizeDepth, sizeWidth, sizeHeight);
        this.droneVisual = droneVisual;
    }

    // Getters and Setters
    public ImageView getDroneVisual() {
        return droneVisual;
    }

    public void setDroneVisual(ImageView droneVisual) {
        this.droneVisual = droneVisual;
    }

    // String representation
    @Override
    public String toString() {
        return "FieldMonitoringDrone [Visual Representation=" + droneVisual + "]";
    }

	@Override
	public void removeUnit(AgriculturalUnit unit) throws Exception {

		
	}

	@Override
	public void addUnit(AgriculturalUnit unit) throws Exception {

		
	}

	@Override
	protected Object nameProperty() {
	
		return null;
	}
}
