package edu.agriTech.model;

public class AgriculturalResource extends AgriculturalUnit {
    
    public AgriculturalResource(String identifier, double value, float xAxisLocation, float yAxisLocation, 
                                float resourceDepth, float resourceWidth, float resourceHeight) {
        super(identifier, value, xAxisLocation, yAxisLocation, resourceDepth, resourceWidth, resourceHeight);
    }

    @Override
    public void addUnit(AgriElement element) throws Exception {
        throw new UnsupportedOperationException("AgriculturalResource cannot add a unit.");
    }

    @Override
    public void removeUnit(AgriElement element) throws Exception {
        throw new UnsupportedOperationException("AgriculturalResource cannot be removed in this context.");
    }

    @Override
    public String toString() {
        return "AgriculturalResource [Identifier=" + getUnitName() + ", Value=" + getCost() + 
               ", X-Axis Location=" + getLocationX() + ", Y-Axis Location=" + getLocationY() + 
               ", Depth=" + getLength() + ", Width=" + getWidth() + ", Height=" + getHeight() + "]";
    }

	@Override
	public void removeUnit(AgriculturalUnit unit) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addUnit(AgriculturalUnit unit) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected Object nameProperty() {
		// TODO Auto-generated method stub
		return null;
	}
}
