package edu.agriTech.model;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleStringProperty;

public abstract class AgriculturalUnit {
    private final SimpleStringProperty unitName;
    private final SimpleDoubleProperty unitCost;
    private final SimpleFloatProperty positionX;
    private final SimpleFloatProperty positionY;
    private final SimpleFloatProperty unitLength;
    private final SimpleFloatProperty unitWidth;
    private final SimpleFloatProperty unitHeight;

    public AgriculturalUnit(String unitName, double unitCost, float positionX, float positionY, 
                            float unitLength, float unitWidth, float unitHeight) {
        this.unitName = new SimpleStringProperty(unitName);
        this.unitCost = new SimpleDoubleProperty(unitCost);
        this.positionX = new SimpleFloatProperty(positionX);
        this.positionY = new SimpleFloatProperty(positionY);
        this.unitLength = new SimpleFloatProperty(unitLength);
        this.unitWidth = new SimpleFloatProperty(unitWidth);
        this.unitHeight = new SimpleFloatProperty(unitHeight);
    }

    // Getter and setter methods
    public String getUnitName() {
        return unitName.get();
    }

    public void setUnitName(String unitName) {
        this.unitName.set(unitName);
    }

    // Other getter and setter methods...

    @Override
    public String toString() {
        return "AgriculturalUnit [Unit Name=" + unitName + ", Cost=" + unitCost + ", Position X=" + positionX 
                + ", Position Y=" + positionY + ", Length=" + unitLength + ", Width=" + unitWidth 
                + ", Height=" + unitHeight + "]";
    }

    public abstract void removeUnit(AgriculturalUnit unit) throws Exception;
    public abstract void addUnit(AgriculturalUnit unit) throws Exception;

	protected abstract Object nameProperty();
}
