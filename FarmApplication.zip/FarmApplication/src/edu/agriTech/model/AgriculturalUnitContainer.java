package edu.agriTech.model;

import java.util.ArrayList;
import java.util.List;

public class AgriculturalUnitContainer extends AgriculturalUnit {
    private List<AgriculturalUnit> containedUnits = new ArrayList<>();

    public AgriculturalUnitContainer(String identifier, double value, float xAxisLocation, float yAxisLocation, 
                                     float unitDepth, float unitWidth, float unitHeight) {
        super(identifier, value, xAxisLocation, yAxisLocation, unitDepth, unitWidth, unitHeight);
    }

    @Override
    public void addUnit(AgriElement element) {
        if (element instanceof AgriculturalUnit) {
            containedUnits.add((AgriculturalUnit) element);
        } else {
            throw new IllegalArgumentException("Invalid unit type.");
        }
    }

    @Override
    public void removeUnit(AgriElement element) {
        containedUnits.remove(element);
    }

    @Override
    public String toString() {
        return "AgriculturalUnitContainer [Identifier=" + getUnitName() + ", Value=" + getCost() + 
               ", X-Axis Location=" + getLocationX() + ", Y-Axis Location=" + getLocationY() + 
               ", Depth=" + getLength() + ", Width=" + getWidth() + ", Height=" + getHeight() + 
               ", Contained Units=" + containedUnits + "]";
    }

	@Override
	public void removeUnit(AgriculturalUnit unit) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addUnit(AgriculturalUnit unit) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected Object nameProperty() {
		// TODO Auto-generated method stub
		return null;
	}
}
