package edu.agriTech.controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.layout.AnchorPane;
import edu.agriTech.AgricultureManagementApp;
import edu.agriTech.MainApp;
import edu.agriTech.model.AgriculturalUnit;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class FarmManagementController {
    @FXML private TreeView<String> unitTreeView;
    @FXML private TableView<AgriculturalUnit> unitTableView;
    @FXML private TableColumn<AgriculturalUnit, String> unitNameColumn;
    @FXML private Button addButton, removeButton, actionButton, visualizeButton, deselectButton, visitButton, scanFarmButton;
    @FXML private AnchorPane visualizationArea;
    @FXML private Label visualizationTitle;
    @FXML private TextField identifierTextField, valueTextField, xCoordTextField, yCoordTextField, depthTextField, widthTextField, heightTextField;
    @FXML private ComboBox<String> operationSelector;
    @FXML private Button applyButton;
    
    private AgricultureManagementApp mainApp;
    private ObservableList<String> operationOptions = FXCollections.observableArrayList("Modify Name", "Modify Location", "Modify Value", "Modify Size");
    private Stage controllerStage;
    private boolean applyClicked = false;

    // Initialize the controller
    @FXML private void initialize() {
        unitTreeView.setRoot(new TreeItem<>("Farm Structure"));
        unitTreeView.getRoot().setExpanded(true);
        operationSelector.setItems(operationOptions);

        // Initialize TableView
        unitNameColumn.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        clearUnitDetails();
        unitTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> updateUnitDetails(newValue));

        // More initializations...
    }

    public void setMainApp(AgricultureManagementApp mainApp) {
        this.mainApp = mainApp;
        unitTableView.setItems(mainApp.getComponentData());
    }

    private void clearUnitDetails() {
        identifierTextField.clear();
        valueTextField.clear();
        xCoordTextField.clear();
        yCoordTextField.clear();
        depthTextField.clear();
        widthTextField.clear();
        heightTextField.clear();
    }

    private void updateUnitDetails(AgriculturalUnit unit) {
        if (unit != null) {
            identifierTextField.setText(unit.getUnitName());
            valueTextField.setText(Double.toString(unit.getCost()));
            xCoordTextField.setText(Float.toString(unit.getLocationX()));
            yCoordTextField.setText(Float.toString(unit.getLocationY()));
            depthTextField.setText(Float.toString(unit.getLength()));
            widthTextField.setText(Float.toString(unit.getWidth()));
            heightTextField.setText(Float.toString(unit.getHeight()));
        } else {
            clearUnitDetails();
        }
    }

    // Handle various action events (add, remove, action, visualize, deselect, etc.)
    @FXML private void handleAdd(ActionEvent event) {
        // Add new unit logic
    	AgriculturalUnit newUnit = new AgriculturalUnit;
        mainApp.getComponentData().add(newUnit);
        updateTreeView(newUnit); // Additional method to update the TreeView
    }

    @FXML private void handleRemove(ActionEvent event) {
        // Remove unit logic
    	int selectedIndex = unitTableView.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            AgriculturalUnit unitToRemove = unitTableView.getItems().get(selectedIndex);
            unitTableView.getItems().remove(selectedIndex);
            removeFromTreeView(unitToRemove); // Additional method to update the TreeView
        } else {
            // Show an alert for no selection
        }
    }

    @FXML private void handleAction(ActionEvent event) {
	        AgriculturalUnit selectedUnit = unitTableView.getSelectionModel().getSelectedItem();
	        if (selectedUnit != null) {
	            // Example action: Rename the unit
	            String newName = identifierTextField.getText(); // Assuming newName is input by the user in identifierTextField
	            selectedUnit.setUnitName(newName);
	            unitTableView.refresh(); // Refresh the TableView to show updated name
	        } else {
	            showAlert("No Selection", "No Agricultural Unit Selected", "Please select a unit in the table.");
	        }
    }


    // More event handling methods...
    
    private void updateTreeView(AgriculturalUnit unit) {
    	TreeItem<String> newItem = new TreeItem<>(unit.getUnitName());
        unitTreeView.getRoot().getChildren().add(newItem);    }

    private void removeFromTreeView(AgriculturalUnit unit) {
    	for (TreeItem<String> child : unitTreeView.getRoot().getChildren()) {
            if (child.getValue().equals(unit.getUnitName())) {
                unitTreeView.getRoot().getChildren().remove(child);
                break;
            }
            }
    }

    // ... [Rest of the existing methods]
    
    private void showAlert(String title, String header, String content) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public void setControllerStage(Stage stage) {
        this.controllerStage = stage;
    }

    public boolean isApplyClicked() {
        return applyClicked;
    }

    // More methods...
}
