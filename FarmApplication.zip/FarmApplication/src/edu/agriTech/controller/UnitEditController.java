package edu.agriTech.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import edu.agriTech.model.AgriculturalUnit;

public class UnitEditController {
    @FXML
    private TextField identifierField, valueField, xAxisField, yAxisField, depthField, widthField, heightField;
    @FXML
    private Button confirmButton, cancelButton;

    private Stage editStage;
    private AgriculturalUnit unit;
    private boolean confirmClicked = false;

    // Initialize controller
    @FXML
    private void initialize() {
    }

    // Set dialog stage
    public void setEditStage(Stage editStage) {
        this.editStage = editStage;
    }

    // Set unit to edit
    public void setUnit(AgriculturalUnit unit) {
        this.unit = unit;

        identifierField.setText(unit.getUnitName());
        valueField.setText(Double.toString(unit.getCost()));
        xAxisField.setText(Float.toString(unit.getLocationX()));
        yAxisField.setText(Float.toString(unit.getLocationY()));
        depthField.setText(Float.toString(unit.getLength()));
        widthField.setText(Float.toString(unit.getWidth()));
        heightField.setText(Float.toString(unit.getHeight()));
    }

    // Check if confirm was clicked
    public boolean isConfirmClicked() {
        return confirmClicked;
    }

    // Handle confirm action
    @FXML
    private void handleConfirm(ActionEvent event) {
        if (isInputValid()) {
            unit.setUnitName(identifierField.getText());
            unit.changeCost(Double.parseDouble(valueField.getText()));
            unit.changeLocationX(Float.parseFloat(xAxisField.getText()));
            unit.changeLocationY(Float.parseFloat(yAxisField.getText()));
            unit.changeLength(Float.parseFloat(depthField.getText()));
            unit.changeWidth(Float.parseFloat(widthField.getText()));
            unit.changeHeight(Float.parseFloat(heightField.getText()));

            confirmClicked = true;
            editStage.close();
        }
    }

    // Handle cancel action
    @FXML
    private void handleCancel(ActionEvent event) {
        editStage.close();
    }

    // Validate user input
    private boolean isInputValid() {
        String errorMessage = "";
        // Validation logic
        // ...

        if (errorMessage.isEmpty()) {
            return true;
        } else {
            // Show error message
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(editStage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText(errorMessage);
            alert.showAndWait();
            return false;
        }
    }
}
