package edu.agriTech;

import java.io.IOException;
import java.lang.reflect.Field;
import java.time.temporal.ChronoField;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import edu.agriTech.controller.FarmManagementController;
import edu.agriTech.controller.UnitEditController;
import edu.agriTech.model.CropField;
import edu.agriTech.model.FieldItem;
import edu.model.StorageFacility;

public class AgricultureManagementApp extends Application {

    private Stage mainStage;
    private ObservableList<CropField> fieldsData = FXCollections.observableArrayList();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage mainStage) {
        this.mainStage = mainStage;
        this.mainStage.setTitle("AgriTech Management Dashboard");
        initializeFieldsData();
        displayManagementDashboard();
    }

    private void initializeFieldsData() {
        fieldsData.add(new StorageFacility("Seed Store", 2000, 20, 20, 100, 100, 100));
    }

    private void displayManagementDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/edu/agriTechview/ManagementDashboard.fxml")); // Correct path
            BorderPane dashboard = loader.load();

            Scene scene = new Scene(dashboard);
            mainStage.setScene(scene);
            mainStage.show();

            FarmManagementController controller = loader.getController();
            controller.setAppManager(this);
            controller.setFieldsData(fieldsData);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ObservableList<ChronoField> getFieldsData() {
        return Field;
    }

    public Stage getMainStage() {
        return mainStage;
    }

    public boolean openFieldEditor(Field item) {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("edu.agriTechview/FieldEditor.fxml")); // Correct path
            BorderPane editorPane = loader.load();

            Stage editorStage = new Stage();
            editorStage.setTitle("Edit Crop Field");
            editorStage.initModality(Modality.WINDOW_MODAL);
            editorStage.initOwner(mainStage);
            Scene scene = new Scene(editorPane);
            editorStage.setScene(scene);

            UnitEditController controller = loader.getController();
            controller.setEditStage(editorStage);
            controller.setCropField(item);

            editorStage.showAndWait();

            return controller.isConfirmClicked();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
